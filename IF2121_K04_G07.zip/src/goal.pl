/* Goal State */

/* Rules */
/* Pemain menang melawan bos */

goal :- write('  __  __   ______   __  __       __     __   ______   __   __    '),nl,
        write(' /\\ \\_\\ \\ /\\  __ \\ /\\ \\/\\ \\     /\\ \\  _ \\ \\ /\\  __ \\ /\\ "-.\\ \\   '),nl,
        write(' \\ \\____ \\\\ \\ \\/\\ \\\\ \\ \\_\\ \\    \\ \\ \\/ ".\\ \\\\ \\ \\/\\ \\\\ \\ \\-.  \\  '),nl,
        write('  \\/\\_____\\\\ \\_____\\\\ \\_____\\    \\ \\__/".~\\_\\\\ \\_____\\\\ \\_\\\\"\\_\\ '),nl,
        write('   \\/_____/ \\/_____/ \\/_____/     \\/_/   \\/_/ \\/_____/ \\/_/ \\/_/ '),nl,
        write('              ...Shall began, Dragon Slayer...'),nl,
        write('          You are a hero of Willy Wangky Theme Park'),nl,nl,sleep(1).

