/* Job: swordsman, archer, sorcerer */
/* character(Nama, Job, Level, MaxHP, HP, DP, AP, Exp) */
characterDB(_, swordsman, _, 3000, _, 2000, 500, _).
characterDB(_, archer, _, 3000, _, 1500, 550, _).
characterDB(_, sorcerer, _, 2500, _, 2500, 600, _).
