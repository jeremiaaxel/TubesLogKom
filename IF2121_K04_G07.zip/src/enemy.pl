/* Axel */
/* Enemy */

/* Fakta */
/* dynamic(current_hp/1) */

/* 
enemy(ID, Name, Type, Level, HP, DP, AP) 
*/

/* 1 */
enemy(1, wolfie, wolf, 1, 1000, 700, 200).
enemy(2, ingus, slime, 1, 3000, 1000, 100).
enemy(3, cendol, goblin, 1, 2000, 900, 150).

/* 2 */
enemy(4, kirain_anjing, wolf, 2, 1100, 700, 300).
enemy(5, slimong, slime, 2, 3200, 1000, 100).
enemy(6, padatan_klorofil, goblin, 2, 2150, 900, 200).

/* 3 */
enemy(7, mountain_wolf, wolf, 3, 1100, 700, 300).
enemy(8, mama_slimemon, slime, 3, 3200, 1000, 100).
enemy(9, mountain_goblin, goblin, 3, 2150, 900, 200).

/* 4 */
enemy(10, wherewolf, wolf, 4, 1100, 700, 300).
enemy(11, rockslime, slime, 4, 3200, 1000, 100).
enemy(12, hemogoblin, goblin, 4, 2150, 900, 200).

/* 5 */
enemy(13, kyrryk, wolf, 5, 1100, 700, 300).
enemy(14, terraslime, slime, 5, 3200, 1000, 100).
enemy(15, tapioca, goblin, 5, 2150, 900, 200).

/* 6 */
enemy(16, standing_wolf, wolf, 6, 1100, 700, 300).
enemy(17, slimeblock, slime, 6, 3200, 1000, 100).
enemy(18, yukinocinta, goblin, 6, 2150, 900, 200).

/* 7 */
enemy(19, pico, wolf, 7, 1100, 700, 300).
enemy(20, merurun, slime, 7, 3200, 1000, 100).
enemy(21, mascheran, goblin, 7, 2150, 900, 200).

/* 8 */
enemy(22, illfang, wolf, 8, 1100, 700, 300).
enemy(23, the_sleepy_eyes, slime, 8, 3200, 1000, 100).
enemy(24, the_skull_rapper, goblin, 8, 2150, 900, 200).

/* 9 */
enemy(25, ravatar_aang, wolf, 9, 1100, 700, 300).
enemy(26, vaseline, slime, 9, 3200, 1000, 100).
enemy(27, baby_thajeer, goblin, 9, 2150, 900, 200).

/* 10 */
enemy(28, wolfu-san, wolf, 10, 1100, 700, 300).
enemy(29, sulaimu-chyan, slime, 10, 3200, 1000, 100).
enemy(30, gurobulinu-kyun, goblin, 10, 2150, 900, 200).

/* bosses */
boss(101, king_meong, boss, 3, 10000, 2000, 500).
boss(102, sir_yon, boss, 5, 299314, 5000, 690).
boss(103, eternity_single, boss, 7, 1111111, 8011, 769).
boss(104, praprak_logkom, boss, 9, 1423599, 9500, 1000).
boss(105, tubes_logkom, boss, 10, 18235959, 9999, 999).



/* Current HP */
/* current_hp([10]). */

/* Rules */